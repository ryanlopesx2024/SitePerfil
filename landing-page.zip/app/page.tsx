import dynamic from 'next/dynamic'
import { Suspense } from 'react'

const Background = dynamic(() => import('@/components/background').then((mod) => mod.Background), { ssr: false })
const InteractiveCursor = dynamic(() => import('@/components/interactive-cursor').then((mod) => mod.InteractiveCursor), { ssr: false })
const ParticleExplosion = dynamic(() => import('@/components/particle-explosion').then((mod) => mod.ParticleExplosion), { ssr: false })
const ScrollProgress = dynamic(() => import('@/components/scroll-progress').then((mod) => mod.ScrollProgress), { ssr: false })

import { HeroSection } from "@/components/hero-section"
import { AboutMeSection } from "@/components/about-me-section"
import { ExperienceSection } from "@/components/experience-section"
import { TechStackSection } from "@/components/tech-stack-section"
import { ProjectsSection } from "@/components/projects-section"
import { SkillsSection } from "@/components/skills-section"
import { EducationSection } from "@/components/education-section"
import { ContactSection } from "@/components/contact-section"
import { Footer } from "@/components/footer"
import { TypingEffect } from "@/components/typing-effect"

export default function Home() {
  return (
    <main className="relative min-h-screen">
      <Suspense fallback={<div className="fixed inset-0 bg-black" />}>
        <Background />
      </Suspense>
      <Suspense fallback={null}>
        <InteractiveCursor />
      </Suspense>
      <Suspense fallback={null}>
        <ParticleExplosion />
      </Suspense>
      <Suspense fallback={null}>
        <ScrollProgress />
      </Suspense>
      <div className="relative z-20">
        <HeroSection />
        <TypingEffect />
        <AboutMeSection />
        <ExperienceSection />
        <TechStackSection />
        <ProjectsSection />
        <SkillsSection />
        <EducationSection />
        <ContactSection />
        <Footer />
      </div>
    </main>
  )
}

