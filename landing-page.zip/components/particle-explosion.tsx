"use client"

import { useEffect, useRef } from "react"

export function ParticleExplosion() {
  const containerRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    const container = containerRef.current
    if (!container) return

    const createParticle = (x: number, y: number) => {
      const particle = document.createElement("div")
      particle.className = "absolute w-2 h-2 bg-purple-500 rounded-full"
      particle.style.left = `${x}px`
      particle.style.top = `${y}px`
      container.appendChild(particle)

      const angle = Math.random() * Math.PI * 2
      const velocity = 1 + Math.random() * 2
      const lifetime = 1000 + Math.random() * 1000

      const animation = particle.animate(
        [
          { transform: "scale(1) translate(0, 0)", opacity: 1 },
          { transform: `scale(0) translate(${Math.cos(angle) * 100}px, ${Math.sin(angle) * 100}px)`, opacity: 0 },
        ],
        { duration: lifetime, easing: "cubic-bezier(0, .9, .57, 1)" },
      )

      animation.onfinish = () => particle.remove()
    }

    const handleClick = (e: MouseEvent) => {
      for (let i = 0; i < 20; i++) {
        createParticle(e.clientX, e.clientY)
      }
    }

    window.addEventListener("click", handleClick)

    return () => {
      window.removeEventListener("click", handleClick)
    }
  }, [])

  return <div ref={containerRef} className="fixed inset-0 pointer-events-none z-20" />
}

