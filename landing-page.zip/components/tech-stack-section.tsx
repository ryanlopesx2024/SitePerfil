"use client"

import { motion } from "framer-motion"
import { Code2, Box, Brain, Bot, Workflow, Database, Cloud, Network } from "lucide-react"

const techCategories = [
  {
    title: "Linguagens",
    icon: Code2,
    items: ["Python", "JavaScript", "TypeScript", "Java"],
  },
  {
    title: "Frameworks",
    icon: Box,
    items: ["React", "Node.js", "FastAPI", "Next.js"],
  },
  {
    title: "IA & ML",
    icon: Brain,
    items: ["Ollama", "LangChain", "TensorFlow", "PyTorch"],
  },
  {
    title: "Chatbots",
    icon: Bot,
    items: ["GPT", "TypeBot", "BotPress", "Rasa"],
  },
  {
    title: "Automação",
    icon: Workflow,
    items: ["NLP", "Zapier", "Make", "n8n"],
  },
  {
    title: "Databases",
    icon: Database,
    items: ["PostgreSQL", "MongoDB", "Redis", "Supabase"],
  },
  {
    title: "DevOps",
    icon: Cloud,
    items: ["Docker", "Kubernetes", "AWS", "GCP"],
  },
  {
    title: "APIs",
    icon: Network,
    items: ["REST", "GraphQL", "WebSockets", "gRPC"],
  },
  {
    title: "Ferramentas",
    icon: Box,
    items: ["Dify", "Portainer", "Nicochat", "CrewAI"],
  },
]

export function TechStackSection() {
  return (
    <section className="py-20 relative">
      <div className="absolute inset-0 bg-gradient-to-b from-blue-500/5 via-transparent to-purple-500/5" />
      <div className="container px-4 relative">
        <motion.h2
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-3xl md:text-4xl font-bold text-center mb-12 text-white"
        >
          Ferramentas & Tecnologias
        </motion.h2>
        <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
          {techCategories.map((category, index) => (
            <motion.div
              key={category.title}
              initial={{ opacity: 0, scale: 0.9 }}
              whileInView={{ opacity: 1, scale: 1 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.1 }}
              className="group relative overflow-hidden rounded-xl bg-white/5 backdrop-blur-sm border border-white/10 p-6 hover:bg-white/10 transition-all duration-300"
            >
              <div className="absolute inset-0 bg-gradient-to-br from-purple-500/10 via-transparent to-blue-500/10 opacity-0 group-hover:opacity-100 transition-opacity" />
              <category.icon className="w-8 h-8 text-purple-400 mb-4" />
              <h3 className="font-bold text-lg mb-4 text-white">{category.title}</h3>
              <div className="space-y-3">
                {category.items.map((item) => (
                  <div key={item} className="flex items-center space-x-2">
                    <div className="h-1.5 w-1.5 rounded-full bg-purple-400" />
                    <span className="text-sm text-white/80">{item}</span>
                  </div>
                ))}
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  )
}

