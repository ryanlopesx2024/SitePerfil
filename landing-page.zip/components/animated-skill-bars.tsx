"use client"

import { motion } from "framer-motion"

const skills = [
  { name: "Desenvolvimento Web", level: 95 },
  { name: "Inteligência Artificial", level: 90 },
  { name: "Machine Learning", level: 85 },
  { name: "DevOps", level: 80 },
  { name: "Cloud Computing", level: 85 },
]

export function AnimatedSkillBars() {
  return (
    <div className="space-y-4">
      {skills.map((skill) => (
        <div key={skill.name} className="relative pt-1">
          <div className="flex mb-2 items-center justify-between">
            <div>
              <span className="text-xs font-semibold inline-block py-1 px-2 uppercase rounded-full text-purple-600 bg-purple-200">
                {skill.name}
              </span>
            </div>
            <div className="text-right">
              <span className="text-xs font-semibold inline-block text-purple-600">{skill.level}%</span>
            </div>
          </div>
          <div className="overflow-hidden h-2 mb-4 text-xs flex rounded bg-purple-200">
            <motion.div
              style={{ width: 0 }}
              animate={{ width: `${skill.level}%` }}
              transition={{ duration: 1, delay: 0.5 }}
              className="shadow-none flex flex-col text-center whitespace-nowrap text-white justify-center bg-purple-500"
            />
          </div>
        </div>
      ))}
    </div>
  )
}

