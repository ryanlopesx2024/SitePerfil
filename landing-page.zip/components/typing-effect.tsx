"use client"

import { useState, useEffect } from "react"
import { motion } from "framer-motion"

const phrases = [
  "Desenvolvedor Full Stack",
  "Especialista em IA",
  "Entusiasta de Automação",
  "Solucionador de Problemas",
]

export function TypingEffect() {
  const [currentPhrase, setCurrentPhrase] = useState(0)
  const [currentText, setCurrentText] = useState("")
  const [isDeleting, setIsDeleting] = useState(false)

  useEffect(() => {
    const timeout = setTimeout(
      () => {
        if (!isDeleting && currentText === phrases[currentPhrase]) {
          setTimeout(() => setIsDeleting(true), 1000)
          return
        }

        if (isDeleting && currentText === "") {
          setIsDeleting(false)
          setCurrentPhrase((current) => (current + 1) % phrases.length)
          return
        }

        const nextText = isDeleting
          ? phrases[currentPhrase].substring(0, currentText.length - 1)
          : phrases[currentPhrase].substring(0, currentText.length + 1)

        setCurrentText(nextText)
      },
      isDeleting ? 50 : 100,
    )

    return () => clearTimeout(timeout)
  }, [currentText, currentPhrase, isDeleting])

  return (
    <motion.div
      className="text-2xl font-bold text-purple-400 mt-4"
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={{ duration: 0.5 }}
    >
      {currentText}
      <span className="animate-blink">|</span>
    </motion.div>
  )
}

