"use client"

import { motion } from "framer-motion"

const projects = [
  {
    title: "Portal IA - Sebrae",
    description: "Desenvolvimento de ferramentas de IA para gerenciamento e suporte a pequenas empresas.",
    tags: ["IA", "Gerenciamento", "Suporte", "Pequenas Empresas"],
  },
  {
    title: "Sistema de Gestão - Sesc",
    description: "Implementação de sistema integrado para gestão de unidades do Sesc.",
    tags: ["Gestão", "Integração", "Desenvolvimento Web"],
  },
  {
    title: "Plataforma de Automação",
    description: "Desenvolvimento de plataforma para automação de processos empresariais.",
    tags: ["Automação", "Processos", "Empresarial"],
  },
]

export function ProjectsSection() {
  return (
    <section className="py-20 relative">
      <div className="absolute inset-0 bg-gradient-to-b from-purple-900/20 via-transparent to-blue-900/20" />
      <div className="container px-4 relative">
        <motion.h2
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-3xl md:text-4xl font-bold text-center mb-12 cyberpunk-font text-white"
        >
          Projetos em Destaque
        </motion.h2>
        <div className="grid gap-8 md:grid-cols-2 lg:grid-cols-3">
          {projects.map((project, index) => (
            <motion.div
              key={project.title}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.2 }}
              className="group relative overflow-hidden rounded-xl bg-white/5 backdrop-blur-sm border border-white/10 p-6"
            >
              <div className="absolute inset-0 bg-gradient-to-br from-purple-500/10 via-transparent to-blue-500/10 opacity-0 group-hover:opacity-100 transition-opacity" />
              <h3 className="font-bold text-xl mb-2 text-white">{project.title}</h3>
              <p className="text-sm text-white/80 mb-4">{project.description}</p>
              <div className="flex flex-wrap gap-2 mb-4">
                {project.tags.map((tag) => (
                  <span
                    key={tag}
                    className="text-xs px-2 py-1 rounded-full bg-purple-500/10 text-white border border-purple-500/20"
                  >
                    {tag}
                  </span>
                ))}
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  )
}

