"use client"

import { motion } from "framer-motion"
import { GraduationCap, Brain, Code } from "lucide-react"

const education = [
  {
    institution: "FAESA",
    period: "Fev/2023 - Jun/2025",
    course: "Análise e Desenvolvimento de Sistemas",
    description: "Foco em linguagens como Python, Java e JavaScript.",
    icon: GraduationCap,
  },
  {
    institution: "Academia Lender[IA]",
    period: "Abr/2024 - Abr/2025",
    course: "Inteligência Artificial",
    description: "Formação em Inteligência Artificial aplicada a negócios.",
    icon: Brain,
  },
  {
    institution: "IT Valley School",
    period: "2023",
    course: "Bootcamp de Inteligência Artificial",
    description: "Certificado de conclusão em IA com foco em aplicações práticas.",
    icon: Brain,
  },
  {
    institution: "IT Valley School",
    period: "2023",
    course: "Bootcamp de Machine Learning",
    description: "Certificado de conclusão com ênfase em Python e algoritmos de ML.",
    icon: Code,
  },
  {
    institution: "EIA",
    period: "2022",
    course: "Inteligência Artificial com Algoritmos Genéticos em R",
    description: "Curso de 7 horas-aula focado em IA e algoritmos genéticos.",
    icon: Brain,
  },
  {
    institution: "Microsoft",
    period: "2023",
    course: "Azure AI - Desenvolvimento de AI",
    description: "Certificação em desenvolvimento de soluções de IA na plataforma Azure.",
    icon: Brain,
  },
]

export function EducationSection() {
  return (
    <section className="py-20 relative">
      <div className="absolute inset-0 bg-gradient-to-b from-purple-900/20 via-transparent to-blue-900/20" />
      <div className="container px-4 relative">
        <motion.h2
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-3xl md:text-4xl font-bold text-center mb-12 text-white"
        >
          Formação Acadêmica
        </motion.h2>
        <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3 max-w-6xl mx-auto">
          {education.map((edu, index) => (
            <motion.div
              key={edu.course}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.1 }}
              className="relative overflow-hidden rounded-xl bg-white/5 backdrop-blur-sm border border-white/10 p-6 hover:bg-white/10 transition-all duration-300"
            >
              <div className="absolute inset-0 bg-gradient-to-br from-purple-500/10 via-transparent to-blue-500/10 opacity-0 group-hover:opacity-100 transition-opacity" />
              <edu.icon className="w-10 h-10 text-purple-400 mb-4" />
              <h3 className="font-bold text-xl mb-2 text-white">{edu.course}</h3>
              <p className="text-sm text-white/80 mb-1">{edu.institution}</p>
              <p className="text-sm text-white/80 mb-2">{edu.period}</p>
              <p className="text-sm text-white">{edu.description}</p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  )
}

