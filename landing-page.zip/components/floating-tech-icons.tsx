"use client"

import { motion } from "framer-motion"
import Image from "next/image"

const techIcons = [
  "/icons/python.svg",
  "/icons/javascript.svg",
  "/icons/react.svg",
  "/icons/nodejs.svg",
  "/icons/tensorflow.svg",
  "/icons/docker.svg",
]

export function FloatingTechIcons() {
  return (
    <div className="fixed inset-0 pointer-events-none z-10">
      {techIcons.map((icon, index) => (
        <motion.div
          key={icon}
          className="absolute"
          initial={{
            x: Math.random() * window.innerWidth,
            y: Math.random() * window.innerHeight,
          }}
          animate={{
            x: Math.random() * window.innerWidth,
            y: Math.random() * window.innerHeight,
          }}
          transition={{
            duration: Math.random() * 10 + 10,
            repeat: Number.POSITIVE_INFINITY,
            repeatType: "reverse",
          }}
        >
          <Image src={icon || "/placeholder.svg"} alt="Tech Icon" width={32} height={32} className="opacity-20" />
        </motion.div>
      ))}
    </div>
  )
}

