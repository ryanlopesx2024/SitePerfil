"use client"

import { Canvas } from "@react-three/fiber"
import { Suspense } from "react"
import { Stars } from "@react-three/drei"
import { Bloom, EffectComposer } from "@react-three/postprocessing"

export function Background() {
  return (
    <div className="fixed inset-0 bg-black">
      <Suspense fallback={null}>
        <Canvas camera={{ position: [0, 0, 1] }}>
          <Stars radius={100} depth={50} count={5000} factor={4} saturation={0} fade speed={1} />
          <EffectComposer>
            <Bloom luminanceThreshold={0} luminanceSmoothing={0.9} height={300} />
          </EffectComposer>
        </Canvas>
      </Suspense>
      <div className="absolute inset-0 bg-gradient-to-b from-black via-purple-900/20 to-black pointer-events-none" />
    </div>
  )
}

