"use client"

import { motion } from "framer-motion"
import { Brain, Zap, Code, Cloud } from "lucide-react"

export function AboutMeSection() {
  return (
    <section id="about" className="py-20 relative">
      <div className="absolute inset-0 bg-gradient-to-b from-purple-900/20 via-transparent to-blue-900/20" />
      <div className="container px-4 relative">
        <motion.h2
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-3xl md:text-4xl font-bold text-center mb-12 text-white"
        >
          Sobre Mim
        </motion.h2>
        <div className="max-w-4xl mx-auto">
          <motion.p
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-lg text-white/80 mb-8"
          >
            Ryan Lopes, sou um desenvolvedor apaixonado por tecnologia e inovação, especializado em Python e
            Inteligência Artificial. Baseado em Vitória, ES, venho construindo uma carreira sólida no universo da
            tecnologia, com mais de um ano de experiência focada em soluções de IA e automação.
          </motion.p>
          <motion.p
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: 0.2 }}
            className="text-lg text-white/80 mb-8"
          >
            Minha jornada começou com programação Python e rapidamente evoluiu para o desenvolvimento de soluções
            complexas em IA.
          </motion.p>
          <div className="grid gap-8 md:grid-cols-2">
            <motion.div
              initial={{ opacity: 0, x: -20 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              className="bg-white/5 backdrop-blur-sm rounded-xl p-6 border border-white/10"
            >
              <Brain className="w-10 h-10 text-purple-400 mb-4" />
              <h3 className="text-xl font-bold text-white mb-4">Expertise em IA</h3>
              <ul className="list-disc list-inside text-white/80 space-y-2">
                <li>Desenvolvimento de agentes autônomos com IA</li>
                <li>Proficiência em TensorFlow, Keras, PyTorch</li>
                <li>Experiência com Scikit-Learn, Numpy, Pandas, Matplotlib</li>
              </ul>
            </motion.div>
            <motion.div
              initial={{ opacity: 0, x: 20 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              className="bg-white/5 backdrop-blur-sm rounded-xl p-6 border border-white/10"
            >
              <Zap className="w-10 h-10 text-purple-400 mb-4" />
              <h3 className="text-xl font-bold text-white mb-4">Automação e Integração</h3>
              <ul className="list-disc list-inside text-white/80 space-y-2">
                <li>Automação de processos</li>
                <li>Integração de sistemas com APIs</li>
                <li>Desenvolvimento de soluções escaláveis</li>
              </ul>
            </motion.div>
            <motion.div
              initial={{ opacity: 0, x: -20 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              className="bg-white/5 backdrop-blur-sm rounded-xl p-6 border border-white/10"
            >
              <Code className="w-10 h-10 text-purple-400 mb-4" />
              <h3 className="text-xl font-bold text-white mb-4">Desenvolvimento</h3>
              <ul className="list-disc list-inside text-white/80 space-y-2">
                <li>Especialização em Python</li>
                <li>Experiência com frameworks modernos</li>
                <li>Foco em soluções de IA e automação</li>
              </ul>
            </motion.div>
            <motion.div
              initial={{ opacity: 0, x: 20 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              className="bg-white/5 backdrop-blur-sm rounded-xl p-6 border border-white/10"
            >
              <Cloud className="w-10 h-10 text-purple-400 mb-4" />
              <h3 className="text-xl font-bold text-white mb-4">Infraestrutura e Cloud</h3>
              <ul className="list-disc list-inside text-white/80 space-y-2">
                <li>Deployments em VPS (Contabo e outros provedores)</li>
                <li>Arquitetura de soluções em nuvem</li>
                <li>Implementação de sistemas escaláveis</li>
              </ul>
            </motion.div>
          </div>
          <motion.p
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: 0.4 }}
            className="text-lg text-white/80 mt-8"
          >
            Além das habilidades técnicas, tenho uma visão estratégica que me permite identificar oportunidades de
            implementação de IA e automação em diferentes contextos empresariais, sempre focando em resultados
            mensuráveis e escaláveis.
          </motion.p>
        </div>
      </div>
    </section>
  )
}

