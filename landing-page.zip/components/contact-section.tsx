"use client"

import { motion } from "framer-motion"
import { PhoneIcon as WhatsApp } from "lucide-react"

export function ContactSection() {
  return (
    <section id="contact" className="py-20 relative">
      <div className="absolute inset-0 bg-gradient-to-b from-purple-900/20 via-transparent to-blue-900/20" />
      <div className="container px-4 max-w-2xl relative">
        <motion.h2
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-3xl md:text-4xl font-bold text-center mb-12 text-white"
        >
          Entre em Contato
        </motion.h2>
        <div className="flex justify-center">
          <motion.a
            href="https://w.app/m34m1s"
            target="_blank"
            rel="noopener noreferrer"
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            className="inline-flex items-center justify-center rounded-full bg-green-500 px-8 py-4 text-lg font-medium text-white transition-all hover:bg-green-600"
          >
            <WhatsApp className="w-6 h-6 mr-2 text-white" />
            Contate-me no WhatsApp
          </motion.a>
        </div>
      </div>
    </section>
  )
}

