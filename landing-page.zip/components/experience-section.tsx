"use client"

import { motion } from "framer-motion"
import { Building2, Code2, Cpu } from "lucide-react"

const experiences = [
  {
    company: "GAO TECH",
    period: "set de 2023 - o momento · 8 meses",
    role: "Analista de IA",
    description:
      "Atuo Home Office como Analista de Inteligência Artificial PJ, realizando a implementação de serviços avançados em servidores e VPS, atendendo grandes empresas como o SEBRAE e SESC.",
    icon: Building2,
    responsibilities: [
      "Configuração e Implementação de LLMs",
      "Desenvolvimento de Chatbots e IA Conversacional",
      "Automação de Processos",
      "Serviços de No-Code",
      "Manutenção e Atualizações",
      "Infraestrutura e Suporte",
      "Integração de APIs",
      "Desenvolvimento de IA no WhatsApp",
      "Utilização de bibliotecas de IA como TensorFlow, PyTorch, e Scikit-learn",
    ],
  },
  {
    company: "LoopeAi",
    period: "abr de 2024 - set de 2024 · 6 meses",
    role: "Analista de Inteligência Artificial",
    description:
      "Atuei como profissional autônomo na LoopeAI, minha empresa de inteligência artificial, desenvolvendo e implementando soluções avançadas para transformar desafios em oportunidades por meio da tecnologia.",
    icon: Code2,
    responsibilities: [
      "Criação de AI Agents",
      "Implementação de serviços em VPS",
      "Desenvolvimento de soluções personalizadas",
      "Automatização de processos",
    ],
  },
  {
    company: "Microlins",
    period: "mar de 2023 - nov de 2023 · 9 meses",
    role: "Técnico de TI",
    description:
      "Atuei como Técnico de Suporte de TI, responsável pela manutenção e suporte da infraestrutura tecnológica da unidade.",
    icon: Cpu,
    responsibilities: [
      "Atendimento aos usuários para resolução de problemas",
      "Realização de diagnósticos, reparos e atualizações",
      "Configuração e manutenção de redes locais (LAN)",
      "Gerenciamento de instalações de sistemas operacionais",
      "Elaboração de relatórios e registros sobre chamados",
      "Apoio em iniciativas de modernização tecnológica",
    ],
  },
]

export function ExperienceSection() {
  return (
    <section id="experience" className="py-20 relative">
      <div className="absolute inset-0 bg-gradient-to-b from-purple-900/20 via-transparent to-blue-900/20" />
      <div className="container px-4 relative">
        <motion.h2
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-3xl md:text-4xl font-bold text-center mb-12 text-white"
        >
          Experiência Profissional
        </motion.h2>
        <div className="space-y-12">
          {experiences.map((exp, index) => (
            <motion.div
              key={exp.company}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.2 }}
              className="group relative overflow-hidden rounded-xl bg-white/5 backdrop-blur-sm border border-white/10 p-6 hover:bg-white/10 transition-all duration-300"
            >
              <div className="absolute inset-0 bg-gradient-to-br from-purple-500/10 via-transparent to-blue-500/10 opacity-0 group-hover:opacity-100 transition-opacity" />
              <div className="flex items-center mb-4">
                <exp.icon className="w-10 h-10 text-purple-400 mr-4" />
                <div>
                  <h3 className="font-bold text-xl text-white">{exp.company}</h3>
                  <p className="text-sm text-white/80">{exp.period}</p>
                </div>
              </div>
              <p className="font-medium mb-4 text-white">{exp.role}</p>
              <p className="text-sm text-white/80 mb-4">{exp.description}</p>
              <h4 className="font-semibold text-white mb-2">Principais responsabilidades:</h4>
              <ul className="list-disc list-inside text-sm text-white/80 space-y-1">
                {exp.responsibilities.map((resp, idx) => (
                  <li key={idx}>{resp}</li>
                ))}
              </ul>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  )
}

