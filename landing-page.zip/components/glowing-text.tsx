"use client"

import { motion } from "framer-motion"

interface GlowingTextProps {
  text: string
  className?: string
}

export function GlowingText({ text, className = "" }: GlowingTextProps) {
  return (
    <motion.span
      className={`relative inline-block ${className}`}
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={{ duration: 0.5 }}
    >
      {text}
      <motion.span
        className="absolute inset-0 blur-lg opacity-50"
        style={{ background: "linear-gradient(45deg, #8b5cf6, #3b82f6)" }}
        animate={{
          opacity: [0.5, 0.7, 0.5],
        }}
        transition={{
          duration: 2,
          repeat: Number.POSITIVE_INFINITY,
          repeatType: "reverse",
        }}
      />
    </motion.span>
  )
}

