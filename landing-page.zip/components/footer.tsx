import { Linkedin, Mail } from "lucide-react"

export function Footer() {
  return (
    <footer className="py-8 border-t border-white/10">
      <div className="container px-4">
        <div className="flex justify-center space-x-6">
          <a
            href="https://www.linkedin.com/in/ryan-lopes-122199226/"
            className="text-white/80 hover:text-purple-400 transition-colors"
            aria-label="LinkedIn"
            target="_blank"
            rel="noopener noreferrer"
          >
            <Linkedin className="w-6 h-6" />
          </a>
          <a
            href="mailto:seuemail@exemplo.com"
            className="text-white/80 hover:text-purple-400 transition-colors"
            aria-label="Email"
          >
            <Mail className="w-6 h-6" />
          </a>
        </div>
        <p className="text-center text-sm text-white/80 mt-4">© 2024 Ryan Lopes. Todos os direitos reservados.</p>
      </div>
    </footer>
  )
}

